package com.rays.model;

import java.util.Date;
import java.util.Arrays;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Lob;
import javax.persistence.Table;


import org.apache.tomcat.util.codec.binary.Base64;
import org.springframework.format.annotation.DateTimeFormat;
import org.springframework.stereotype.Component;

@Entity
@Table(name = "user")
@Component
public class User {

	@Id   //Specifies the primary key of an entity
	@GeneratedValue(strategy = GenerationType.AUTO)   // 
	private Integer id;
	//@Column(name = "uname")
	private String Name;
	private String Password;
	@DateTimeFormat(pattern = "yyyy-mm-dd")
	private Date DOB;
	private String State;
	private String City;
	private String Aadhar;
	private Long Mobile;
	private Integer Height;
	private String Gender;
	private String Role;
	private String BattingStyle;
	private String BowlingStyle;
	@Lob
	private byte[] Pic;
	private String agree;


	public User() {
		super();
		// TODO Auto-generated constructor stub
	}
	public User(Integer id, String Name, String Password, Date DOB,String State, 
			String City,String Aadhar, Long Mobile, Integer Height, String Gender,
			String Role, String BattingStyle,String BowlingStyle, String Agree ) {
		super();
		this.id = id;
		this.Name = Name;
		this.Password = Password;
		this.DOB = DOB;
		this.State = State;
		this.City = City;
		this.Aadhar = Aadhar;
		this.Mobile = Mobile;
		this.Height = Height;
		this.Gender= Gender;
		this.Role = Role;
		this.BattingStyle = BattingStyle;
		this.BowlingStyle = BowlingStyle;
		this.agree=Agree;

	}


	public User(Integer id, String Name, String Password, Date DOB,String State,String Aadhar, Long Mobile, 
			Integer Height, String Gender,String Role, String BattingStyle,String BowlingStyle, 
			String City,String gender,
			String Agree ,byte[] Pic) {
		super();
		this.id = id;
		this.Name = Name;
		this.Password = Password;
		this.DOB = DOB;
		this.State = State;
		this.City = City;
		this.Aadhar = Aadhar;
		this.Mobile = Mobile;
		this.Height = Height;
		this.Gender= Gender;
		this.Role = Role;
		this.BattingStyle = BattingStyle;
		this.BowlingStyle = BowlingStyle;
		this.agree=Agree;

		this.Pic = Pic;
	}
	public Integer getId() {
		return id;
	}
	public void setId(Integer id) {
		this.id = id;
	}
	public String getName() {
		return Name;
	}
	public void setName(String name) {
		Name = name;
	}
	public String getPassword() {
		return Password;
	}
	public void setPassword(String password) {
		Password = password;
	}
	public Date getDOB() {
		return DOB;
	}
	public void setDOB(Date dOB) {
		DOB = dOB;
	}
	public String getState() {
		return State;
	}
	public void setState(String state) {
		State = state;
	}
	public String getCity() {
		return City;
	}
	public void setCity(String city) {
		City = city;
	}
	public String getAadhar() {
		return Aadhar;
	}
	public void setAadhar(String aadhar) {
		Aadhar = aadhar;
	}
	public Long getMobile() {
		return Mobile;
	}
	public void setMobile(Long mobile) {
		Mobile = mobile;
	}
	public Integer getHeight() {
		return Height;
	}
	public void setHeight(Integer height) {
		Height = height;
	}
	public String getGender() {
		return Gender;
	}
	public void setGender(String gender) {
		Gender = gender;
	}
	public String getRole() {
		return Role;
	}
	public void setRole(String role) {
		Role = role;
	}
	public String getBattingStyle() {
		return BattingStyle;
	}
	public void setBattingStyle(String battingStyle) {
		BattingStyle = battingStyle;
	}
	public String getBowlingStyle() {
		return BowlingStyle;
	}
	public void setBowlingStyle(String bowlingStyle) {
		BowlingStyle = bowlingStyle;
	}
	public byte[] getPic() {
		return Pic;
	}
	public void setPic(byte[] pic) {
		Pic = pic;
	}
	public String getAgree() {
		return agree;
	}
	public void setAgree(String agree) {
		this.agree = agree;
	}
	@Override
	public String toString() {
		return "User [id=" + id + ", Name=" + Name + ", Password=" + Password + ", DOB=" + DOB + ", State=" + State
				+ ", City=" + City + ", Aadhar=" + Aadhar + ", Mobile=" + Mobile + ", Height=" + Height + ", Gender="
				+ Gender + ", Role=" + Role + ", BattingStyle=" + BattingStyle + ", BowlingStyle=" + BowlingStyle
				+ ", Pic=" + Arrays.toString(Pic) + ", agree=" + agree + "]";
	}


}
